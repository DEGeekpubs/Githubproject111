package com.example.mova

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
