enum RequestState {
  loading,
  loaded,
  error,
}

enum AppTheme {
  darkTheme,
  lightTheme,
  spaceTheme,
}
